import React, {useState} from 'react';
const ParkingTable = (props) => {
    
    return (
       <div className="col-sm-8 col-md-8">
			<div className="card mb-1">                
				<div className="card-body">
					<table className="table table-sm">
						<thead>
							<tr>
								<th>Sr. No</th>
								<th>Car No.</th>
								<th>Color</th>
								<th>Slot</th>
							</tr>
						</thead>
					<tbody>				
					<tr></tr>
					</tbody>
					</table>
				</div>
			</div>        
			</div>
        )
        
    }
export default ParkingTable;