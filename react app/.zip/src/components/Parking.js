import React, { useEffect,useState, useRef  } from 'react';
import AddCar from './addCar'; 
import ParkingTable from './parkingTable';
import parkingSlots from "../data.js";

function Parking(){
    const [parkings, setparkings] = useState([]);
    const initialParking = {  slot: null,carNo: '',color: '',slotAvil:false };
    const [currentParking, setCurrentParking] = useState(initialParking);
    let avaialebleSlots = [1,2,3,4,5,6,7,8];
    
    const addParkings = (parkings) => {    
       // console.log(parkings);    
        parkings.slot =  avaialebleSlots[0];
        parkings.slotAvil = true; 
        avaialebleSlots.shift();   
        setparkings(parkings);    
        console.log(parkings);     
      };

      
        return ( 
            <>
            <div className="row">
            <h4>Parking Slot: <span className="badge bg-primary" >{avaialebleSlots.length} </span></h4>
                <AddCar addParkings={addParkings}/>  
                <ParkingTable/>
            </div>
                   

            </>
         );
        
}
 
export default Parking