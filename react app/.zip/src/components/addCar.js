import React, {useState} from 'react';

const AddCar = (props) => {   
    const colors = ['Red','Black','White',"Blue"];
    const [err,setErr] = useState('');
    const initialParking = {  slot: null,carNo: '',color: '',slotAvil:false };
    const [parkings, setParking] = useState(initialParking);
    const avaialebleSlots = [1,2,3,4,5,6,7,8];
    
    const handleSubmit = e => {
        e.preventDefault();  
        if (parkings.carNo) {
            handleChange(e, props.addParkings(parkings));
        } 
    }
    const handleChange = e => {
        const {name, value} = e.target;
        setParking({...parkings, [name]: value});
    }

    return (
        <div className="col-sm-12 col-md-4 col-lg-4">
        <form onSubmit={handleSubmit}>
            <div className="mb-3">
                        <label htmlFor="" className="form-label">Car No:</label>
                        <input type="text" className="form-control" id="" name="carNo" onChange={handleChange} />
                        <p className="text-danger">
                            {err}
                        </p>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="" className="form-label">Example textarea</label>
                        <select className="form-select" name="color" onChange={handleChange}>
                            {
                                colors.map((color,i)=>(
                                    <option key={color} value={color}>{color}</option>
                                ))
                            }
                        </select>
                    </div>                 
                    <button type="submit" className="btn btn-primary" onClick={handleSubmit}>Add Parking</button>
        </form>
        </div>
    )
}

export default AddCar;