import React from 'react'

const Greet = props  => {  
    return (     
       <div className="col-md-4">
           <div className="card mb-1">
               <div className="card-header bg-success">
                    <h6 className="card-title text-white">
                        "Title"
                    </h6>
               </div>
               <div className="card-body">
                    "Body"
               </div>
           </div>
          
       </div>
    )   
} 

export default Greet