const parkingSlots = [
    {
        slot: 1,
        carNo: 'mh-23-dl-3023',
        color: 'Red',
        slotAvil:true
    },
    {
        slot: 2,
        carNo: '',
        color: '',
        slotAvil:false
    }
];

export default parkingSlots;